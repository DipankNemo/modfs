#!/usr/bin/env bash
#
# TIER 3: boot a composed module set for real, under UEFI, and check it from
# inside the running system.
#
#   sudo ./scripts/11_boot_test.sh base webserver apache
#   sudo ./scripts/11_boot_test.sh --name runA base curl jq ...
#
# Tiers 1 and 2 verify metadata and the composed filesystem. Neither can see a
# conflict that only exists at runtime -- two modules both binding port 80
# compose perfectly and fail the moment systemd starts them.
#
# What it does:
#   1. compose the set and reconcile it (same path as 04/07)
#   2. install a kernel INTO THE IMAGE ONLY -- boot scaffolding is not module
#      content, so no artefact and no module definition changes
#   3. pack a GPT/UEFI disk: ESP with systemd-boot, ext4 root
#   4. boot headless under OVMF with the console on ttyS0
#   5. in the guest: dpkg --audit, systemctl state and failed units, and every
#      per-module probe from specs/modules.yaml -- then power off
#   6. parse the serial log for the verdict
#
# Exit: 0 everything passed, 1 something in the guest failed, 2 the harness
# broke (no boot, timeout, missing tool). Run B below is EXPECTED to exit 1 --
# that is the finding, not a malfunction.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "${HERE}/config.sh"
source "${HERE}/scripts/lib.sh"

die2() { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*" >&2; exit 2; }
[ "$(id -u)" -eq 0 ] || die2 "must run as root (mounts, chroot, loop devices)"

NAME=""; TIMEOUT=600; MEM=2048; IMG_MB=3072; KNOWN_NEG=0; EXPECT="all-green"; INTERACTIVE=0
while [ $# -gt 0 ]; do
    case "$1" in
        --name)    [ $# -ge 2 ] || die2 "--name needs a value";    NAME="$2"; shift 2 ;;
        --timeout) [ $# -ge 2 ] || die2 "--timeout needs a value"; TIMEOUT="$2"; shift 2 ;;
        --mem)     [ $# -ge 2 ] || die2 "--mem needs a value";     MEM="$2"; shift 2 ;;
        --size-mb) [ $# -ge 2 ] || die2 "--size-mb needs a value"; IMG_MB="$2"; shift 2 ;;
        --interactive) INTERACTIVE=1; shift ;;
        --known-negative) KNOWN_NEG=1; EXPECT="tier-1 rejection"; shift ;;
        --expect) [ $# -ge 2 ] || die2 "--expect needs a value"; EXPECT="$2"; shift 2 ;;
        -*) die2 "unknown option: $1" ;;
        *) break ;;
    esac
done
[ $# -ge 2 ] || die2 "usage: $0 [--name TAG] base <module> [module...]"
MODULES=("$@")
[ -n "$NAME" ] || NAME="$(IFS=-; echo "${MODULES[*]}")"
NAME="${NAME:0:60}"

# C1. --name reached a root `rm -rf` unvalidated; "../../modules" would have
# deleted the artefact store. Validate every identifier, bound every number.
require_ident "$NAME" "run name"
for m in "${MODULES[@]}"; do require_ident "$m" "module name"; done
require_uint "$TIMEOUT" 30 7200 "--timeout"
require_uint "$MEM"     256 65536 "--mem"
require_uint "$IMG_MB"  512 131072 "--size-mb"

for t in qemu-system-x86_64 sgdisk mkfs.vfat mkfs.ext4 losetup rsync; do
    command -v "$t" >/dev/null 2>&1 || die2 "missing tool: $t"
done
OVMF_CODE=/usr/share/OVMF/OVMF_CODE_4M.fd
OVMF_VARS=/usr/share/OVMF/OVMF_VARS_4M.fd
[ -f "$OVMF_CODE" ] || OVMF_CODE=/usr/share/ovmf/OVMF.fd
[ -f "$OVMF_CODE" ] || die2 "no OVMF firmware (apt install ovmf)"

# C5. Run bundles are timestamped and immutable. Reusing --name can no
# longer delete prior evidence, because nothing is ever deleted: a collision
# is an error. The bundle also lives outside BUILD_DIR, which config.sh calls
# scratch.
RUN_TS="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_ID="${NAME}-${RUN_TS}"
BOOT_ROOT="${RESULTS_DIR}/boot"
mkdir -p "$BOOT_ROOT"
B="$(safe_child "$BOOT_ROOT" "$RUN_ID")"
[ -e "$B" ] && die2 "run bundle already exists: $B"
mkdir -p "$B" || die2 "cannot create run bundle: $B"
SERIAL="$B/serial.log"
# Scratch for this run stays in BUILD_DIR; only evidence lands in the bundle.
C="${BUILD_DIR}/boot-${RUN_ID}"
IMG="$C/disk.img"; VARS="$C/OVMF_VARS.fd"
reset_workdir "$C"; mkdir -p "$C"/{upper,work,merged}
M="$C/merged"

# Written BEFORE any mount, chroot, apt transaction or image write, so an
# aborted run still leaves a record of what was attempted and why.
python3 - "$B/run.json" "$RUN_ID" "$RUN_TS" "$EXPECT" "$KNOWN_NEG" "$TIMEOUT" \
         "$MEM" "$IMG_MB" "${MODULES[@]}" <<'RJ'
import json, os, sys
out, run_id, ts, expect, kn, timeout, mem, img, mods = (
    sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5],
    sys.argv[6], sys.argv[7], sys.argv[8], sys.argv[9:])
json.dump({'run_id': run_id, 'started_utc': ts, 'tier': 3,
           'expectation': expect, 'known_negative': kn == '1',
           'modules': mods, 'timeout_s': int(timeout),
           'mem_mb': int(mem), 'image_mb': int(img),
           'argv': sys.argv[1:], 'status': 'started'},
          open(out, 'w'), indent=2)
RJ
{
    echo "commit      $(git -C "$HERE" rev-parse HEAD 2>/dev/null || echo unknown)"
    echo "dirty       $(git -C "$HERE" status --porcelain 2>/dev/null | wc -l) file(s) modified"
    git -C "$HERE" status --porcelain 2>/dev/null | sed 's/^/  /'
    echo "host        $(uname -srm)  $(hostname)"
    echo "qemu        $(qemu-system-x86_64 --version 2>/dev/null | head -1)"
    echo "ovmf        $OVMF_CODE"
    for f in config.sh scripts/11_boot_test.sh scripts/reconcile.py \
             scripts/05_check.sh specs/modules.yaml; do
        [ -f "$HERE/$f" ] && echo "sha256      $(sha256sum "$HERE/$f" | cut -c1-16)  $f"
    done
} > "$B/source.txt" 2>&1

FINISHED=0
finish() {               # finish <verdict> <exit-code>
    FINISHED=1
    python3 - "$B/result.json" "$B/run.json" "$1" "$2" "$B/kernel.json" <<'FJ' 2>/dev/null || true
import json, sys, time, os
out, runf, verdict, rc, kernf = sys.argv[1:6]
try:    run = json.load(open(runf))
except Exception: run = {}
# The resolved kernel ABI is recorded by the pack step into its own file, so
# a run that dies before the kernel install still produces a result.json --
# with kernel null, which is the truth about that run rather than a guess.
try:    kern = json.load(open(kernf))
except Exception: kern = None
started = run.get('started_utc', '')
json.dump({'run_id': run.get('run_id'), 'verdict': verdict, 'exit_code': int(rc),
           'expectation': run.get('expectation'),
           'known_negative': run.get('known_negative'),
           'modules': run.get('modules'),
           'kernel': kern,
           'started_utc': started,
           'finished_utc': time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()),
           'duration_s': int(time.time() - os.path.getmtime(runf))},
          open(out, 'w'), indent=2)
FJ
    return 0
}

# Loop devices are not tracked by lib.sh's mount stack, so they need their own
# teardown -- a leaked loop device survives the script and blocks the image.
LOOPDEV=""
boot_cleanup() {
    [ -n "$LOOPDEV" ] && { umount "$C/mnt/esp" 2>/dev/null; umount "$C/mnt/root" 2>/dev/null
                           losetup -d "$LOOPDEV" 2>/dev/null; }
    return 0
}
# Every exit path records a result, including die2 and a signal. Run A left
# no record at all; that is precisely what C5 is meant to prevent.
trap 'RC_TRAP=$?; boot_cleanup
      [ "${FINISHED:-0}" -eq 1 ] || finish ABORTED "$RC_TRAP"
      cleanup' EXIT
# Same reasoning as lib.sh: record the outcome, release resources, then die
# with the signal rather than returning into the middle of an image build.
trap 'boot_cleanup; [ "${FINISHED:-0}" -eq 1 ] || finish INTERRUPTED 130
      unmount_all; trap - EXIT INT; kill -s INT $$'  INT
trap 'boot_cleanup; [ "${FINISHED:-0}" -eq 1 ] || finish TERMINATED 143
      unmount_all; trap - EXIT TERM; kill -s TERM $$' TERM

# ---- 0. admission --------------------------------------------------------
# C3. Run A died inside APT because a tier-1-rejected set (the MTA pair) was
# composed anyway. Integrity and admission come first, always; a deliberate
# negative must say so explicitly and is never called "admitted".
log "verifying bundle integrity"
verify_bundle "${MODULES[@]}" > "$B/integrity.txt" 2>&1 || {
    cat "$B/integrity.txt" >&2; finish INTEGRITY_FAIL 2; die2 "bundle integrity failed"; }

tier1_admit "$B/tier1.txt" "${MODULES[@]}"; ADM=$?
case "$ADM" in
    0) ADMITTED=yes;  log "tier-1: ADMITTED" ;;
    1) ADMITTED=no;   log "tier-1: REJECTED" ;;
    *) ADMITTED=broken; log "tier-1: CHECKER BROKE" ;;
esac
if [ "$ADM" -ne 0 ] && [ "$KNOWN_NEG" -eq 0 ]; then
    tail -20 "$B/tier1.txt" | sed 's/^/    /'
    finish NOT_ADMITTED 2
    die2 "set not admitted by tier 1; re-run with --known-negative to boot it anyway"
fi
[ "$ADM" -eq 0 ] || log "proceeding as a KNOWN NEGATIVE -- this result is not a verification"

# ---- 1. compose ----------------------------------------------------------
log "composing: ${MODULES[*]}"
LAYERS=(); LOWERS=()
for m in "${MODULES[@]}"; do
    sq="${MOD_DIR}/${m}.sqsh"; [ -f "$sq" ] || die2 "missing artefact ${sq}"
    mp="$C/ro_${m}"; mkdir -p "$mp"
    do_mount -o loop,ro "$sq" "$mp"
    LOWERS=("ro_${m}" "${LOWERS[@]}"); LAYERS+=("${m}=${mp}")
done
# RELATIVE lowerdir names, mounted from inside $C. The kernel caps mount DATA at
# one page (4096 bytes) and overlay packs every lower layer into that one string,
# so absolute paths make the ceiling depend on how deep the scratch directory
# happens to sit. A 37-module set auto-named from its own module list produced an
# 83-character run directory and a 4319-byte option string, and failed -- while
# the identical set under `--name maxsub` came to 2213 bytes and worked.
# Composability must not depend on the length of a directory name. Relative
# names cost ~13 bytes per layer instead of ~112: the same set is now 419 bytes,
# moving the ceiling from roughly 35 layers to several hundred.
OPTS="lowerdir=$(IFS=:; echo "${LOWERS[*]}"),upperdir=upper,workdir=work"
if [ "${#OPTS}" -ge 4096 ]; then
    die2 "overlay options are ${#OPTS} bytes, over the kernel's 4096-byte limit, at ${#MODULES[@]} layers. Shorten module names or compose in stages."
fi
( cd "$C" && mount -t overlay overlay -o "$OPTS" merged ) \
    || die2 "overlay mount failed: ${#OPTS} bytes of options, ${#MODULES[@]} layers"
track_mount "$M"
mount_chroot_fs "$M"
write_sources_list "$M"
write_chroot_policy "$M"

python3 "${HERE}/scripts/reconcile.py" --merged "$M" --groups-out "$C/alt.groups" \
        "${LAYERS[@]}" > "$B/reconcile.log" 2>&1 || die2 "reconciliation failed"
REGEN_FAIL=0
while read -r g; do
    [ -n "$g" ] || continue
    in_chroot "$M" update-alternatives --auto "$g" >/dev/null 2>&1 </dev/null \
        || { warn "update-alternatives --auto ${g} failed"; REGEN_FAIL=$((REGEN_FAIL+1)); }
done < "$C/alt.groups"
in_chroot "$M" ldconfig >/dev/null 2>&1 </dev/null \
    || { warn "ldconfig failed"; REGEN_FAIL=$((REGEN_FAIL+1)); }
# The boot image must not be built on a half-reconciled tree.
[ "$REGEN_FAIL" -eq 0 ] || { finish REGEN_FAIL 2
    die2 "reconciliation regeneration failed ${REGEN_FAIL} time(s)"; }
log "reconciled: $(grep -c . <<<"$(in_chroot "$M" dpkg-query -W -f '${binary:Package}\n' 2>/dev/null </dev/null)") packages"

# ---- 2. kernel: scaffolding, into the image only -------------------------
# The artefacts exclude /run by design, so base's /etc/resolv.conf -- a
# symlink to ../run/systemd/resolve/stub-resolv.conf -- DANGLES in a composed
# view and apt cannot resolve anything. 02_build_delta.sh never hits this
# because it builds on base.dir, the raw tree, which still has /run.
# Supply a real resolver for the pack step only, and put the symlink back
# before the image is written so no host DNS config ships in it.
# Same story for directories. SQUASH_EXCLUDES drops proc, sys, dev, run, tmp,
# var/tmp, var/lib/apt/lists and var/cache/apt/archives -- the DIRECTORIES,
# not merely their contents -- so a composed tree has neither the mountpoints
# systemd needs nor the scratch space apt needs. mount_chroot_fs happens to
# create proc/sys/dev/run, which is why nothing noticed until now; it does not
# create /tmp, and apt fails on its first temporary file.
log "creating runtime directories the artefacts exclude"
mkdir -p "$M"/tmp "$M"/var/tmp \
         "$M"/var/lib/apt/lists/partial "$M"/var/cache/apt/archives/partial
chmod 1777 "$M/tmp" "$M/var/tmp"
chmod 755  "$M/var/lib/apt/lists" "$M/var/cache/apt/archives"
chmod 700  "$M/var/lib/apt/lists/partial" "$M/var/cache/apt/archives/partial"

RESOLV_SRC=/run/systemd/resolve/resolv.conf
[ -r "$RESOLV_SRC" ] || RESOLV_SRC=/etc/resolv.conf
[ -r "$RESOLV_SRC" ] || die2 "no usable resolv.conf on the host for the pack step"
rm -f "$M/etc/resolv.conf"
cp -L "$RESOLV_SRC" "$M/etc/resolv.conf" || die2 "cannot stage resolv.conf"

log "installing kernel into the image (not into any module)"
in_chroot "$M" apt-get update -qq </dev/null > "$B/apt.log" 2>&1 \
    || die2 "apt update failed in the merged view, see $B/apt.log"
# iproute2 is here for the same reason as the kernel: it is OBSERVABILITY
# SCAFFOLDING, not module content. Run m2 (base+apache) reported
# "ss unavailable" and produced no socket evidence at all, because `ss` only
# happened to be present in the other runs -- nginx pulls iproute2 in, apache
# does not. Diagnostic tooling the matrix depends on must be guaranteed, never
# incidental to which modules were selected.
in_chroot "$M" apt-get install -y -qq --no-install-recommends \
    linux-image-generic initramfs-tools iproute2 </dev/null >> "$B/apt.log" 2>&1 \
    || die2 "kernel install failed, see $B/apt.log"
# The pack-step apt-get update/install re-creates exactly the scratch that
# SQUASH_EXCLUDES strips from every artefact: 298 MB of package indices in
# var/lib/apt/lists and 411 MB of .debs in var/cache/apt/archives. config.sh
# already rules that this is build scaffolding and not module content, so it
# must not ship in the image either -- 02_build_delta.sh drops it the same way
# after its own installs. Leaving it in cost 709 MB of a 3072 MB image and was
# where rsync hit ENOSPC. Keep the DIRECTORIES: apt needs them at runtime.
log "dropping apt scratch the image must not carry"
in_chroot "$M" apt-get clean </dev/null >/dev/null 2>&1 \
    || die2 "apt-get clean failed in the merged view"
rm -rf "$M/var/lib/apt/lists"/* "$M/var/cache/apt/archives"/*.deb

# Back to what the modules actually ship, so the image carries no host DNS.
rm -f "$M/etc/resolv.conf"
ln -s ../run/systemd/resolve/stub-resolv.conf "$M/etc/resolv.conf"

KVER=$(in_chroot "$M" sh -c 'ls -1 /boot/vmlinuz-* 2>/dev/null | sed "s|.*/vmlinuz-||" | sort -V | tail -1' </dev/null)
[ -n "$KVER" ] || die2 "no kernel in /boot after install"
log "kernel ${KVER}"

# ---- 2b. RECORD THE RESOLVED KERNEL ABI ----------------------------------
# linux-image-generic is a META package: its version (5.15.0.185.166) is NOT
# the ABI, and the thing a prebuilt out-of-tree module must match is the ABI
# package version (5.15.0-185.195) and the /lib/modules/<abi> directory name.
# Until now the pack step resolved that at run time and threw it away, so
# nothing downstream could check that a driver module matches the kernel it
# will meet -- STATE_OF_PLAY section 7 item 9 names exactly this as the CUDA
# blocker. It is recorded here, next to the boot it describes.
#
# Written to its OWN file rather than into run.json, for the same reason
# run.json is written before the first mount: this is evidence, and evidence
# must survive the run that produced it failing later. finish() folds it into
# result.json on every exit path, and records null when the run died first.
log "recording resolved kernel ABI"
in_chroot "$M" dpkg-query -W -f '${binary:Package}\t${Version}\n' \
    'linux-image*' 'linux-modules*' 'linux-headers*' 'linux-generic*' \
    'linux-firmware' 'linux-objects-*' 'linux-signatures-*' \
    </dev/null 2>/dev/null | sort > "$C/kernel-packages.tsv" || true
KSHA=$(sha256sum "$M/boot/vmlinuz-${KVER}" 2>/dev/null | cut -d" " -f1)
python3 - "$B/kernel.json" "$KVER" "$C/kernel-packages.tsv" "${KSHA:-}" \
         "$SNAPSHOT_ID" "$SUITE" "$ARCH" "$M" <<'KJ' \
    || die2 "cannot record the resolved kernel ABI"
import json, os, sys
out, kver, pkgf, ksha, snap, suite, arch, merged = sys.argv[1:9]
pkgs = {}
try:
    for line in open(pkgf, encoding='utf-8'):
        if '\t' in line:
            n, v = line.rstrip('\n').split('\t', 1)
            # dpkg-query -W with a glob also lists packages dpkg merely
            # KNOWS about, with an empty version. Recording those would imply
            # the image carries a kernel it does not have.
            if n and v: pkgs[n] = v
except OSError:
    pass
# The ABI package version is what an out-of-tree module package must equal.
# Prefer linux-modules-<abi>, because that is the package whose version the
# nvidia module packages are built against; fall back to linux-image-<abi>.
abi_version = None
abi_source = None
for cand in ('linux-modules-' + kver, 'linux-image-' + kver,
             'linux-image-unsigned-' + kver):
    if cand in pkgs:
        abi_version, abi_source = pkgs[cand], cand
        break
# <abi> is the /lib/modules directory name a .ko must live under. Record what
# actually exists rather than asserting it: a composed system that carries a
# REAL lib/ directory outranks base's lib -> usr/lib symlink, and the two
# paths below are how that is told apart afterwards.
moddir = os.path.join(merged, 'usr/lib/modules', kver)
real_lib_modules = os.path.join(merged, 'lib/modules', kver)
lib_is_symlink = os.path.islink(os.path.join(merged, 'lib'))
json.dump({'abi': kver,
           'abi_package': abi_source,
           'abi_package_version': abi_version,
           'meta_package_version': pkgs.get('linux-image-generic'),
           'vmlinuz_sha256': ksha or None,
           'snapshot': snap, 'suite': suite, 'arch': arch,
           'usr_lib_modules_present': os.path.isdir(moddir),
           'lib_is_symlink': lib_is_symlink,
           'real_lib_modules_present': (not lib_is_symlink
                                        and os.path.isdir(real_lib_modules)),
           'packages': pkgs},
          open(out, 'w'), indent=2, sort_keys=True)
print("  abi %s  (%s = %s)" % (kver, abi_source, abi_version))
KJ

# ---- 3. in-guest test harness -------------------------------------------
python3 - "${SPEC_DIR}/modules.yaml" "$M/etc/modfs-probes" "${MODULES[@]}" <<'PY' \
    || die2 "cannot build the probe list"
import sys, yaml
spec, out, mods = sys.argv[1], sys.argv[2], sys.argv[3:]
doc = yaml.safe_load(open(spec, encoding='utf-8')) or {}
probes = {m['name']: str(m['probe']) for m in (doc.get('modules') or [])
          if m.get('name') and m.get('probe')}
with open(out, 'w', encoding='utf-8') as f:
    for m in mods:
        if m in probes: f.write("%s|%s\n" % (m, probes[m]))
print("  probes for %d module(s)" % sum(1 for m in mods if m in probes))
PY

# The boot matrix asserts the units the MODULES bring, not base's background
# services: a unit that is absent, masked or never enabled is exactly the
# failure mode a "list the failed units" check cannot see.
#
# Enable symlinks point at ABSOLUTE paths inside the guest root
# (/lib/systemd/system/nginx.service). Testing -e here resolves them against
# the HOST, where they usually do not exist -- which silently dropped
# nginx.service and kept only those base units the host happens to have
# installed too. Test the link itself, never its target.
: > "$M/etc/modfs-units"
for m in "${MODULES[@]}"; do
    [ "$m" = base ] && continue
    for wants in "$C/ro_${m}"/etc/systemd/system/*.target.wants \
                 "$C/ro_${m}"/usr/lib/systemd/system/*.target.wants; do
        [ -d "$wants" ] || continue
        for u in "$wants"/*.service; do
            [ -L "$u" ] || [ -f "$u" ] || continue
            basename "$u"
        done
    done
done | sort -u > "$M/etc/modfs-units"
log "expected units: $(tr '\n' ' ' < "$M/etc/modfs-units")"

cat > "$M/usr/local/sbin/modfs-boottest" <<'GUEST'
#!/bin/sh
# Runs inside the booted guest. Everything goes to the serial console, which
# is the only channel the harness can read.
#
# /dev/console, NOT /dev/ttyS0. agetty calls vhangup() on its tty while it sets
# up, which invalidates every OTHER process's open fd to that terminal. This
# script holds one fd for its whole run, so it was racing the serial getty:
# whoever touched ttyS0 first won. nginx/apache runs happened to open after
# agetty had settled and were fine; base+postgres+mysql shifted boot timing by
# about a second, opened FIRST, and had its fd hung up under it. The symptom is
# brutal to diagnose -- the first write lands, every later write fails EIO in
# silence, and the run looks like a harness that never started. systemd's own
# messages were never affected because systemd writes to /dev/console. No getty
# owns /dev/console, so nothing vhangups it.
exec > /dev/console 2>&1

# Liveness marker, emitted BEFORE any waiting. Without it the harness is
# silent for up to 180 s, which makes three very different outcomes look
# identical in the serial log: the unit never started, the redirect to
# /dev/ttyS0 failed, or the harness is simply still waiting. Run acct-pm
# (base+postgres+mysql) powered off at 187.6 s having printed NOTHING, and
# that ambiguity is the only reason the cause could not be read off the log.
echo "===MODFS-HARNESS-ALIVE=== uptime=$(cut -d' ' -f1 /proc/uptime)"

# THE OBSERVER IS THE JOB, and this is structural rather than a race.
# systemctl(1): the state is "starting" until the job queue goes idle for the
# FIRST time -- and this harness is itself a queued job for as long as it runs.
# Run acct-mp finally named it: "360 modfs-boottest.service start running".
# Moving to a timer removed the DEADLOCK but not the job, so the old
# `is-system-running --wait` burned its full 120 s on every run and could not
# have done otherwise. It is gone: a wait that cannot succeed is not a wait.
#
# Second and independent: the old drain loop used `grep -c . || echo 0`, but
# `grep -c` prints 0 AND exits 1 on no match, so `|| echo 0` appended a SECOND
# zero and n became the two-line string "0\n0". `[ "$n" = "0" ]` was therefore
# never true and the loop could not break even on a genuinely empty queue.
# Two defects, one symptom (iterations=60 forever). wc -l always exits 0.
jobs_foreign() {
    systemctl list-jobs --no-legend --plain 2>/dev/null \
        | grep -v 'modfs-boottest\.service' | wc -l
}
i=0
while [ "$i" -lt 120 ]; do
    [ "$(jobs_foreign)" -eq 0 ] && break
    i=$((i + 1)); sleep 1
done
echo "MODFS wait-jobs iterations=$i foreign=$(jobs_foreign) uptime=$(cut -d' ' -f1 /proc/uptime)"

# Re-open the console immediately before the report. The waits above are where
# a TTYVHangup lands -- serial-getty is Type=idle, so its vhangup fires
# whenever the boot transaction finally settles, which is exactly the window we
# spend waiting. A hung-up fd fails EIO in silence, so the one thing we must
# never do is carry a fd ACROSS that window and into the report. This costs
# nothing and makes the report independent of who hung up what while we waited.
exec > /dev/console 2>&1

echo "===MODFS-BOOTTEST-BEGIN==="
echo "MODFS state: $(systemctl is-system-running 2>&1)"
echo "MODFS jobs-remaining: $(systemctl list-jobs --no-legend --plain 2>/dev/null | wc -l)"
echo "MODFS jobs-foreign: $(jobs_foreign)"
# Every run so far reports exactly 1 outstanding job and none of them says WHICH.
# That one job is why `is-system-running --wait` returns 124 and why the reported
# state can sit at "starting", so naming it is the difference between a number we
# cannot act on and a fact we can.
systemctl list-jobs --no-legend --plain 2>/dev/null | sed 's/^/MODFS job /' 

echo "MODFS failed-begin"
systemctl list-units --state=failed --no-legend --plain 2>/dev/null \
    | awk '{print "MODFS failed-unit " $1}'
echo "MODFS failed-end"

# Per expected unit: enabled/active state, substate, exit status, restarts,
# and the unit's own journal. This is what turns "apache failed" from an
# inference about port 80 into recorded cause.
if [ -r /etc/modfs-units ]; then
    while read -r u; do
        [ -n "$u" ] || continue
        en=$(systemctl is-enabled "$u" 2>&1 | head -1)
        ac=$(systemctl is-active  "$u" 2>&1 | head -1)
        sub=$(systemctl show -p SubState --value "$u" 2>/dev/null)
        st=$(systemctl show -p ExecMainStatus --value "$u" 2>/dev/null)
        nr=$(systemctl show -p NRestarts --value "$u" 2>/dev/null)
        rs=$(systemctl show -p Result --value "$u" 2>/dev/null)
        echo "MODFS UNIT $u enabled=$en active=$ac sub=$sub exec=$st restarts=$nr result=$rs"
        echo "MODFS UNITLOG-BEGIN $u"
        journalctl -b -u "$u" --no-pager -o short 2>/dev/null | tail -25
        echo "MODFS UNITLOG-END $u"
    done < /etc/modfs-units
fi

# Who actually owns the listening sockets. With two web servers this is the
# difference between "apache failed" and "nginx holds 0.0.0.0:80".
echo "MODFS LISTEN-BEGIN"
ss -ltnup 2>/dev/null || echo "(ss unavailable)"
echo "MODFS LISTEN-END"

dpkg --audit > /tmp/audit.out 2>&1
if [ $? -eq 0 ] && [ ! -s /tmp/audit.out ]; then
    echo "MODFS CHECK audit PASS"
else
    echo "MODFS CHECK audit FAIL"
    sed 's/^/MODFS auditline /' /tmp/audit.out | head -20
fi

if [ -r /etc/modfs-probes ]; then
    while IFS='|' read -r name probe; do
        [ -n "$probe" ] || continue
        out=$(timeout 30 sh -c "$probe" 2>&1); rc=$?
        if [ "$rc" -eq 0 ]; then echo "MODFS PROBE $name PASS"
        else
            echo "MODFS PROBE $name FAIL rc=$rc"
            printf '%s\n' "$out" | head -5 | sed 's/^/MODFS probeout /'
        fi
    done < /etc/modfs-probes
fi

echo "===MODFS-BOOTTEST-END==="
sync
systemctl poweroff -i 2>/dev/null || poweroff -f
GUEST
chmod +x "$M/usr/local/sbin/modfs-boottest"

# Triggered by a TIMER, not wanted by multi-user.target. As part of the boot
# transaction the harness could never observe boot completing, because it was
# itself the job holding it open.
cat > "$M/etc/systemd/system/modfs-boottest.service" <<'UNIT'
[Unit]
Description=modfs tier-3 boot test
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/modfs-boottest
StandardOutput=journal+console
TimeoutStartSec=300
UNIT
cat > "$M/etc/systemd/system/modfs-boottest.timer" <<'TIMER'
[Unit]
Description=run the modfs tier-3 boot test after boot settles
[Timer]
OnBootSec=5s
AccuracySec=1s
[Install]
WantedBy=timers.target
TIMER
mkdir -p "$M/etc/systemd/system/timers.target.wants"
if [ "$INTERACTIVE" -eq 1 ]; then
    # EXPLORATION MODE, not a test. The harness ends in `systemctl poweroff`, so
    # arming it here would shut the machine down seconds after you reached a
    # prompt. Leave the unit on disk (handy for running it by hand) but do not
    # arm the timer, and autologin root on both consoles: the guest has no root
    # password, so without this there is no way in.
    log "interactive: harness NOT armed, autologin on tty1 and ttyS0"
    for u in getty@tty1 serial-getty@ttyS0; do
        mkdir -p "$M/etc/systemd/system/${u}.service.d"
        cat > "$M/etc/systemd/system/${u}.service.d/autologin.conf" <<'AL'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin root --noclear %I $TERM
AL
    done
else
    ln -sf ../modfs-boottest.timer \
           "$M/etc/systemd/system/timers.target.wants/modfs-boottest.timer"
fi
printf 'modfs-guest\n' > "$M/etc/hostname"
# Without this systemd waits 90 s for a root fs entry that does not exist.
printf 'LABEL=modfsroot / ext4 defaults 0 1\n' > "$M/etc/fstab"

remove_chroot_policy "$M"

# ---- 4. pack a UEFI disk -------------------------------------------------
log "packing ${IMG_MB} MB UEFI image"
rm -f "$IMG"; truncate -s "${IMG_MB}M" "$IMG"
sgdisk -Z "$IMG" >/dev/null 2>&1
sgdisk -n 1:0:+128M -t 1:ef00 -c 1:ESP \
       -n 2:0:0     -t 2:8300 -c 2:modfsroot "$IMG" >/dev/null 2>&1 \
    || die2 "sgdisk failed"
LOOPDEV=$(losetup --show -f -P "$IMG") || die2 "losetup failed"
# PARTITION NODES ARE CREATED ASYNCHRONOUSLY, so testing that they EXIST can
# succeed a moment before the kernel will let anything open them. Observed
# 2026-09-19 on the first GPU boot attempt: `[ -e ${LOOPDEV}p1 ]` passed and
# mkfs.vfat then failed, on an image that the identical command formats without
# complaint when run by hand seconds later. Three squashfs loop mounts are
# already held at this point and the host carries 36 snap loop devices, which is
# the load that makes the window visible. Wait for the partitions to be USABLE,
# not merely present.
command -v udevadm >/dev/null 2>&1 && udevadm settle --timeout=20 >/dev/null 2>&1
for _try in $(seq 1 50); do
    blockdev --getsize64 "${LOOPDEV}p1" >/dev/null 2>&1 \
        && blockdev --getsize64 "${LOOPDEV}p2" >/dev/null 2>&1 && break
    sleep 0.1
done
blockdev --getsize64 "${LOOPDEV}p1" >/dev/null 2>&1 \
    || die2 "partition ${LOOPDEV}p1 never became usable after losetup -P"
blockdev --getsize64 "${LOOPDEV}p2" >/dev/null 2>&1 \
    || die2 "partition ${LOOPDEV}p2 never became usable after losetup -P"
# And keep the reason. `>/dev/null 2>&1 || die2 "mkfs.vfat failed"` discarded
# the only evidence of WHY, which is the same defect as the silent harness in
# the 2026-09-16 entry: a failure that reports its existence and nothing else.
mkfs.vfat -F32 -n ESP "${LOOPDEV}p1" > "$B/mkfs.log" 2>&1 \
    || { sed 's/^/    /' "$B/mkfs.log" >&2; die2 "mkfs.vfat failed, see $B/mkfs.log"; }
mkfs.ext4 -q -L modfsroot "${LOOPDEV}p2" >> "$B/mkfs.log" 2>&1 \
    || { sed 's/^/    /' "$B/mkfs.log" >&2; die2 "mkfs.ext4 failed, see $B/mkfs.log"; }

mkdir -p "$C/mnt/esp" "$C/mnt/root"
mount "${LOOPDEV}p1" "$C/mnt/esp"  || die2 "cannot mount ESP"
mount "${LOOPDEV}p2" "$C/mnt/root" || die2 "cannot mount root"

log "copying the composed tree"
rsync -aHAX --numeric-ids \
      --exclude='/proc/*' --exclude='/sys/*' --exclude='/dev/*' --exclude='/run/*' \
      --exclude='/var/lib/apt/lists/*' --exclude='/var/cache/apt/archives/*.deb' \
      "$M/" "$C/mnt/root/" > "$B/rsync.log" 2>&1 || die2 "rsync failed, see $B/rsync.log"

# SQUASH_EXCLUDES drops proc, sys, dev, run, tmp and var/tmp from every
# artefact -- the DIRECTORIES, not just their contents. That is right for an
# artefact (they are runtime, not module content) but it means a composed tree
# has no mountpoints, and systemd cannot mount the API filesystems without
# them. Tiers 1 and 2 never saw this because mount_chroot_fs mkdir -p's them
# first. Creating them here is image scaffolding, exactly like the kernel.
log "creating runtime mountpoints (excluded from artefacts by design)"
for d in proc sys dev run tmp var/tmp; do mkdir -p "$C/mnt/root/$d"; done
chmod 555 "$C/mnt/root/proc" "$C/mnt/root/sys"
chmod 755 "$C/mnt/root/dev"  "$C/mnt/root/run"
chmod 1777 "$C/mnt/root/tmp" "$C/mnt/root/var/tmp"

# systemd-boot ships inside systemd, which base already has. BOOTX64.EFI is
# the removable-media path, so it boots without writing UEFI NVMRAM.
STUB="$M/usr/lib/systemd/boot/efi/systemd-bootx64.efi"
[ -f "$STUB" ] || die2 "no systemd-bootx64.efi in the composed tree"
mkdir -p "$C/mnt/esp/EFI/BOOT" "$C/mnt/esp/loader/entries" "$C/mnt/esp/modfs"
cp "$STUB" "$C/mnt/esp/EFI/BOOT/BOOTX64.EFI"
cp "$M/boot/vmlinuz-${KVER}"    "$C/mnt/esp/modfs/vmlinuz"
cp "$M/boot/initrd.img-${KVER}" "$C/mnt/esp/modfs/initrd.img"
printf 'default modfs\ntimeout 0\nconsole-mode max\n' > "$C/mnt/esp/loader/loader.conf"
INTERACTIVE_CONSOLE=""
[ "$INTERACTIVE" -eq 1 ] && INTERACTIVE_CONSOLE="console=tty0 "
cat > "$C/mnt/esp/loader/entries/modfs.conf" <<ENTRY
title   modfs composed system
linux   /modfs/vmlinuz
initrd  /modfs/initrd.img
options root=LABEL=modfsroot rw ${INTERACTIVE_CONSOLE}console=ttyS0,115200 systemd.log_target=console panic=10
ENTRY

sync
umount "$C/mnt/esp"; umount "$C/mnt/root"
losetup -d "$LOOPDEV"; LOOPDEV=""
unmount_all                       # release the composed overlay before booting

# ---- 5. boot -------------------------------------------------------------
cp "$OVMF_VARS" "$VARS" 2>/dev/null || die2 "no OVMF vars template"
ACCEL=tcg; [ -w /dev/kvm ] && ACCEL=kvm
log "booting under QEMU (accel=${ACCEL}, timeout ${TIMEOUT}s)"
: > "$SERIAL"
if [ "$INTERACTIVE" -eq 1 ]; then
    # No timeout and no -no-reboot: you decide when it ends. Close the window or
    # type `poweroff`. Serial is still captured, so the run bundle is a complete
    # record of an exploratory session too.
    QDISP="gtk"
    [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] || { QDISP="vnc"; log "no DISPLAY; serving VNC on :1 -- connect to localhost:5901"; }
    log "interactive boot: close the window or run 'poweroff' to end"
    if [ "$QDISP" = "gtk" ]; then
        # -serial mon:stdio, NOT file:. The first interactive run autologged
        # root successfully -- onto the SERIAL console, which file: makes
        # write-only, so there was a live root shell nobody could type into,
        # while the gtk window showed tty1 with the kernel and systemd logging
        # over the top of it. Put the shell in the terminal that launched this,
        # where typing works, and keep the window for watching the boot.
        # (mon:stdio also means Ctrl-A X quits QEMU.)
        log "shell is HERE in this terminal; the window shows the video console"
        log "quit with Ctrl-A then X, or type 'poweroff' in the guest"
        qemu-system-x86_64 \
            -machine q35,accel="${ACCEL}" -m "$MEM" -smp 2 \
            -drive if=pflash,format=raw,unit=0,readonly=on,file="$OVMF_CODE" \
            -drive if=pflash,format=raw,unit=1,file="$VARS" \
            -drive file="$IMG",format=raw,if=virtio \
            -display gtk -serial mon:stdio \
            2> "$B/qemu.log"
    else
        qemu-system-x86_64 \
            -machine q35,accel="${ACCEL}" -m "$MEM" -smp 2 \
            -drive if=pflash,format=raw,unit=0,readonly=on,file="$OVMF_CODE" \
            -drive if=pflash,format=raw,unit=1,file="$VARS" \
            -drive file="$IMG",format=raw,if=virtio \
            -vnc :1 -serial "file:$SERIAL" \
            > "$B/qemu.log" 2>&1
    fi
    QRC=$?
    log "qemu exited ${QRC}"
    echo
    echo " serial log: ${SERIAL}"
    echo " disk image: ${IMG}  (scratch; delete with: rm -rf ${C})"
    echo " run bundle: ${B}"
    echo
    echo " interactive session -- NO VERDICT. This composes and boots the set for"
    echo " exploration; it does not verify it. Use a normal run for evidence."
    exit 0
fi
timeout --foreground "$TIMEOUT" qemu-system-x86_64 \
    -machine q35,accel="${ACCEL}" -m "$MEM" -smp 2 \
    -drive if=pflash,format=raw,unit=0,readonly=on,file="$OVMF_CODE" \
    -drive if=pflash,format=raw,unit=1,file="$VARS" \
    -drive file="$IMG",format=raw,if=virtio \
    -display none -serial "file:$SERIAL" -no-reboot \
    > "$B/qemu.log" 2>&1
QRC=$?
log "qemu exited ${QRC}, serial log $(wc -c < "$SERIAL") bytes"

# ---- 6. verdict ----------------------------------------------------------
echo
echo "========================================================================"
echo " TIER-3 BOOT TEST: ${MODULES[*]}"
echo "========================================================================"
python3 - "$SERIAL" "$QRC" "$TIMEOUT" "$B" "$ADMITTED" "$KNOWN_NEG" <<'PY'
import os, re, sys
serial_path, qrc, timeout, bundle, admitted, known_neg = sys.argv[1:7]
serial = open(serial_path, errors='replace').read()
qrc, known_neg = int(qrc), known_neg == '1'

def bail(msg, extra=()):
    print("\n  " + msg)
    for line in extra: print("    " + line[:110])
    sys.exit(2)

if '===MODFS-BOOTTEST-BEGIN===' not in serial:
    tail = [l for l in serial.split('\n') if l.strip()][-15:]
    if qrc == 124:
        bail("QEMU hit the %ss timeout -- boot hung or never started." % timeout, tail)
    if not tail:
        bail("serial log is EMPTY: firmware never handed off, or no console.")
    # The ALIVE marker separates "the unit never ran" from "the unit ran and
    # stalled". Before it existed both looked like an empty serial log.
    alive = re.search(r'===MODFS-HARNESS-ALIVE=== uptime=(\S+)', serial)
    if alive:
        waits = re.findall(r'MODFS wait-\S+ \S+ uptime=(\S+)', serial)
        bail("the harness STARTED (t=%ss) but never reached its report.%s"
             % (alive.group(1),
                "  Last wait checkpoint: t=%ss." % waits[-1] if waits else
                "  It never cleared its first wait."), tail)
    bail("the guest never reached the test harness.", tail)
if '===MODFS-BOOTTEST-END===' not in serial:
    bail("harness started but did not finish -- guest died mid-test.",
         [l for l in serial.split('\n') if l.strip()][-15:])

state = (re.search(r'MODFS state: (.+)', serial) or [None, '?'])[1].strip()
jobs  = (re.search(r'MODFS jobs-remaining: (\d+)', serial) or [None, '?'])[1]
failed = re.findall(r'MODFS failed-unit (\S+)', serial)
checks = re.findall(r'MODFS CHECK (\S+) (PASS|FAIL)', serial)
probes = re.findall(r'MODFS PROBE (\S+) (PASS|FAIL)', serial)
units  = re.findall(r'MODFS UNIT (\S+) enabled=(\S*) active=(\S*) sub=(\S*)'
                    r' exec=(\S*) restarts=(\S*) result=(\S*)', serial)

# Preserve the matrix as evidence, not only as terminal output.
with open(os.path.join(bundle, 'units.txt'), 'w') as f:
    for u in units:
        f.write("%-28s enabled=%-10s active=%-10s sub=%-10s exec=%-4s restarts=%-3s result=%s\n" % u)
listen = re.search(r'MODFS LISTEN-BEGIN\n(.*?)MODFS LISTEN-END', serial, re.S)
open(os.path.join(bundle, 'listeners.txt'), 'w').write(listen.group(1) if listen else '')
with open(os.path.join(bundle, 'journal.txt'), 'w') as f:
    for m in re.finditer(r'MODFS UNITLOG-BEGIN (\S+)\n(.*?)MODFS UNITLOG-END', serial, re.S):
        f.write("===== %s =====\n%s\n" % (m.group(1), m.group(2)))

print("\n  tier-1 admission : %s%s" % (admitted, "  (KNOWN NEGATIVE)" if known_neg else ""))
foreign = (re.search(r'MODFS jobs-foreign: (\d+)', serial) or [None, None])[1]
print("  systemd state    : %s   (jobs remaining: %s)" % (state, jobs))
for j in re.findall(r'MODFS job (.+)', serial):
    print("    outstanding job: %s" % j.strip()[:90])
if foreign is not None and int(foreign) == 0 and state == 'starting':
    # systemctl(1): "starting" holds until the job queue goes idle for the
    # FIRST time, and the harness is itself a queued job. With no FOREIGN job
    # outstanding this is the expected reading, not an unsettled system.
    print("    ^ steady: the only outstanding job is the harness itself")
print("  failed units     : %d%s" % (len(failed), "  " + ", ".join(failed) if failed else ""))
if units:
    print("\n  unit matrix")
    for name, en, ac, sub, ex, nr, res in units:
        flag = "" if ac == 'active' else "   <-- not active"
        print("    %-26s %-9s %-9s sub=%-9s exit=%-3s result=%s%s"
              % (name, en, ac, sub, ex, res, flag))
if listen:
    rows = [l for l in listen.group(1).split('\n')
            if l.strip() and not l.startswith('Netid')]
    if rows:
        print("\n  listening sockets")
        for l in rows[:10]: print("    " + l.strip()[:104])
for n, r in checks: print("\n  check %-10s %s" % (n, r))
for n, r in probes: print("  probe %-10s %s" % (n, r))

bad = [n for n, r in checks + probes if r == 'FAIL']
print()
if qrc != 0:
    print("  NOTE: QEMU exited %d despite a complete run -- treated as broken." % qrc)
    sys.exit(2)
if bad:    print("  FAILED checks/probes: %s" % ', '.join(bad))
if failed: print("  FAILED units: %s" % ', '.join(failed))
if known_neg:
    print("  KNOWN NEGATIVE -- this run is an observation of a rejected set,")
    print("  not a verification. Nothing here says the set is composable.")
    sys.exit(1)
if not bad and not failed:
    print("  ALL GREEN -- every expected unit active, every probe passed")
print("========================================================================")
sys.exit(0 if (not bad and not failed) else 1)
PY
RC=$?
case "$RC" in
    0) finish PASS 0 ;;
    1) finish "$([ "$KNOWN_NEG" -eq 1 ] && echo KNOWN_NEGATIVE_OBSERVED || echo FAIL)" 1 ;;
    *) finish BROKEN 2 ;;
esac
echo
echo " serial log: ${SERIAL}"
echo " disk image: ${IMG}  (scratch; delete with: rm -rf ${C})"
echo " run bundle: ${B}  (evidence -- do not delete)"
exit "$RC"
