import os, re, sys
serial_path, qrc, timeout, bundle, admitted, known_neg = sys.argv[1:7]
serial = open(serial_path, errors='replace').read()
qrc, known_neg = int(qrc), known_neg == '1'

def bail(msg, extra=()):
    print("\n  " + msg)
    for line in extra: print("    " + line[:110])
    sys.exit(2)

if '===MODFS-BOOTTEST-BEGIN===' not in serial:
    tail = [l for l in serial.split('\n') if l.strip()][-15:]
    if qrc == 124:
        bail("QEMU hit the %ss timeout -- boot hung or never started." % timeout, tail)
    if not tail:
        bail("serial log is EMPTY: firmware never handed off, or no console.")
    # The ALIVE marker separates "the unit never ran" from "the unit ran and
    # stalled". Before it existed both looked like an empty serial log.
    alive = re.search(r'===MODFS-HARNESS-ALIVE=== uptime=(\S+)', serial)
    if alive:
        waits = re.findall(r'MODFS wait-\S+ \S+ uptime=(\S+)', serial)
        bail("the harness STARTED (t=%ss) but never reached its report.%s"
             % (alive.group(1),
                "  Last wait checkpoint: t=%ss." % waits[-1] if waits else
                "  It never cleared its first wait."), tail)
    bail("the guest never reached the test harness.", tail)
if '===MODFS-BOOTTEST-END===' not in serial:
    bail("harness started but did not finish -- guest died mid-test.",
         [l for l in serial.split('\n') if l.strip()][-15:])

state = (re.search(r'MODFS state: (.+)', serial) or [None, '?'])[1].strip()
jobs  = (re.search(r'MODFS jobs-remaining: (\d+)', serial) or [None, '?'])[1]
failed = re.findall(r'MODFS failed-unit (\S+)', serial)
checks = re.findall(r'MODFS CHECK (\S+) (PASS|FAIL)', serial)
probes = re.findall(r'MODFS PROBE (\S+) (PASS|FAIL)', serial)
units  = re.findall(r'MODFS UNIT (\S+) enabled=(\S*) active=(\S*) sub=(\S*)'
                    r' exec=(\S*) restarts=(\S*) result=(\S*)', serial)

# Preserve the matrix as evidence, not only as terminal output.
with open(os.path.join(bundle, 'units.txt'), 'w') as f:
    for u in units:
        f.write("%-28s enabled=%-10s active=%-10s sub=%-10s exec=%-4s restarts=%-3s result=%s\n" % u)
listen = re.search(r'MODFS LISTEN-BEGIN\n(.*?)MODFS LISTEN-END', serial, re.S)
open(os.path.join(bundle, 'listeners.txt'), 'w').write(listen.group(1) if listen else '')
with open(os.path.join(bundle, 'journal.txt'), 'w') as f:
    for m in re.finditer(r'MODFS UNITLOG-BEGIN (\S+)\n(.*?)MODFS UNITLOG-END', serial, re.S):
        f.write("===== %s =====\n%s\n" % (m.group(1), m.group(2)))

print("\n  tier-1 admission : %s%s" % (admitted, "  (KNOWN NEGATIVE)" if known_neg else ""))
foreign = (re.search(r'MODFS jobs-foreign: (\d+)', serial) or [None, None])[1]
print("  systemd state    : %s   (jobs remaining: %s)" % (state, jobs))
for j in re.findall(r'MODFS job (.+)', serial):
    print("    outstanding job: %s" % j.strip()[:90])
if foreign is not None and int(foreign) == 0 and state == 'starting':
    # systemctl(1): "starting" holds until the job queue goes idle for the
    # FIRST time, and the harness is itself a queued job. With no FOREIGN job
    # outstanding this is the expected reading, not an unsettled system.
    print("    ^ steady: the only outstanding job is the harness itself")
print("  failed units     : %d%s" % (len(failed), "  " + ", ".join(failed) if failed else ""))
if units:
    print("\n  unit matrix")
    for name, en, ac, sub, ex, nr, res in units:
        flag = "" if ac == 'active' else "   <-- not active"
        print("    %-26s %-9s %-9s sub=%-9s exit=%-3s result=%s%s"
              % (name, en, ac, sub, ex, res, flag))
if listen:
    rows = [l for l in listen.group(1).split('\n')
            if l.strip() and not l.startswith('Netid')]
    if rows:
        print("\n  listening sockets")
        for l in rows[:10]: print("    " + l.strip()[:104])
for n, r in checks: print("\n  check %-10s %s" % (n, r))
for n, r in probes: print("  probe %-10s %s" % (n, r))

bad = [n for n, r in checks + probes if r == 'FAIL']
print()
if qrc != 0:
    print("  NOTE: QEMU exited %d despite a complete run -- treated as broken." % qrc)
    sys.exit(2)
if bad:    print("  FAILED checks/probes: %s" % ', '.join(bad))
if failed: print("  FAILED units: %s" % ', '.join(failed))
if known_neg:
    print("  KNOWN NEGATIVE -- this run is an observation of a rejected set,")
    print("  not a verification. Nothing here says the set is composable.")
    sys.exit(1)
if not bad and not failed:
    print("  ALL GREEN -- every expected unit active, every probe passed")
print("========================================================================")
sys.exit(0 if (not bad and not failed) else 1)
